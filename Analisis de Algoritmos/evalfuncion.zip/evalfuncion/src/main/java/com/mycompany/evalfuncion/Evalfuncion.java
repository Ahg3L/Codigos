/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.evalfuncion;

/**
 *
 * @author Ahg3L
 */
public class Evalfuncion {
    public static void main(String[] args) {
        evaluarfuncion wind = new evaluarfuncion();
        wind.setVisible(true);
    }
}
