package com.mycompany.ordenamiento;

import java.util.Arrays;

public class Ordenamiento{
    // Programa principal
    public static void main(String[] args) {
        
        ventana wind = new ventana();
        wind.setVisible(true);
    }
}
